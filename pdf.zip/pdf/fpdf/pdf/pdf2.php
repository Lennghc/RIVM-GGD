<?php
require('../fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->Image('img1.jpg',0,0,297,-300);
$pdf->SetFont('Arial','B',20);
$pdf->Cell(40,45,'PDF bestand door Tygo Houweling');
$pdf->Ln();
$pdf->SetFont('Arial','i',12);
$pdf->MultiCell(75,5,"sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.");
$pdf->Image('img1.jpg',0,275,297,-300);
$pdf->Output();
?>
<!--  -->