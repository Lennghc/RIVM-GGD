<?php
ob_start();

include("../database/config.php");

include("../database/opendb.php");

include("../functions/alertMsg.php");

require("fpdf/fpdf.php");



//Make sure the session is running

if(!isset($_SESSION)){

    session_start();

}

if( !isset($_SESSION['userid']) ){

    $_SESSION['message'] = alertMsg('U moet ingelogd zijn om deze functie te gebruiken!', null, "danger");

    header("Location: ../index.php");

    exit;

}
    class PDF extends FPDF {

    // Page header

        function Header() {

            // Arial bold 15

            $this->SetFont('Arial','B',15);

            // Move to the right

            $this->Cell(80);

            // Title

            $this->Cell(30,10,'Reservering',0,0,'C');

            // Line break

            $this->Ln(20);

        }

    

        // Page footer

        function Footer() {

            // Position at 1.5 cm from bottom

            $this->SetY(-15);

            // Arial italic 8

            $this->SetFont('Arial','I',8);

            // Page number

            $this->Cell(0,15,'� ALLE RECHTEN VOORBEHOUDEN',0,0,'C');

        }

    }

    $query = "SELECT bookings.timeslot, bookings.vaccination, bookings.id, bookings.date, vaccinations.productname, vaccinations.manufacturer, locations.city, locations.adres, locations.zipcode, locations.houseNumber ";

    $query .= "FROM bookings, locations, vaccinations ";

    $query .= "WHERE bookings.userID = ? ";

    $query .= "AND vaccinations.id = bookings.vaccination ";

    $query .= "AND bookings.location = locations.id ";

    $query .= "AND bookings.done != 1 ";

    $query .= "ORDER BY bookings.date";



    $preparedquery = $dbaselink->prepare($query);

    $preparedquery->bind_param("i", $_SESSION['userid']);

    $preparedquery->execute();



    if ($preparedquery->errno) {

        echo "Fout bij uitvoeren commando";

    } else {

        $result = $preparedquery->get_result();

        if ($result->num_rows === 0) {

            $_SESSION['message'] = alertMsg('U heeft geen afspraak(en) gemaakt!', null, "danger");
            header("Location: /index.php");
            exit;

        } else {
            while($row = $result->fetch_assoc()){

                if(!isset($dataPdf)) {
                    $dataPdf =  array(
                        array("Datum: " . $row['date'],
                        "Tijd: " . $row['timeslot'],
                        "Vaccinatie informatie;\nProductnaam: " . $row['productname'] . " \nLeverancier: " . $row['manufacturer'],
                        "Locatie informatie;\nAdres: " . $row['adres'] . " " . $row['houseNumber'] . " \nStad: " . $row['city']
                        ) 
                    );
                } else {
                    array_push($dataPdf, 
                        array("Datum: " . $row['date'],
                        "Tijd: " . $row['timeslot'],
                        "Vaccinatie informatie;\nProductnaam: " . $row['productname'] . " \nLeverancier: " . $row['manufacturer'],
                        "Locatie informatie;\nAdres: " . $row['adres'] . " " . $row['houseNumber'] . " \nStad: " . $row['city']
                        ) 
                    );
                }

            } 

        }

    }
    $preparedquery->close();
    include("/database/dbclose.php");
    
    $pdf = new PDF();

    for ($i=0; $i < count($dataPdf); $i++) { 
        $pdf->AddPage();

        $pdf->SetFont('Arial','B',14);
    
        $pdf->Image('../img/rivm_logo_login.png',10,10,15,15);
    
        $pdf->Ln(25);

        $pdf->Multicell(85,10,$dataPdf[$i][3],0);

        $pdf->Ln();
    
        $pdf->Multicell(85,10,$dataPdf[$i][2],0);
    
        $pdf->Ln();
    
        $pdf->Cell(60,10,$dataPdf[$i][0],0);
    
        $pdf->Ln();
    
        $pdf->Cell(80,10,$dataPdf[$i][1],0);
    }
    
    ob_clean();

	// save file
	$pdf->Output('output.pdf', 'I');

	?>